var class_factory_king =
[
    [ "FactoryKing", "class_factory_king.html#ad6762ceddcc10d41b5652e17455d3503", null ],
    [ "~FactoryKing", "class_factory_king.html#adbf2005c439f045fb97bdb86147181a7", null ],
    [ "buildPieces", "class_factory_king.html#a0d5fd0a7340ab7bb50fe63e119c3a3ef", null ]
];