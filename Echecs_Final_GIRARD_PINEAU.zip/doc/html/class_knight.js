var class_knight =
[
    [ "Knight", "class_knight.html#ae39d8e49ade7c0b66cf35dad69f2d2db", null ],
    [ "~Knight", "class_knight.html#a2754123d6876babe915f4da8f761361b", null ],
    [ "movement", "class_knight.html#ab228b385a3154ecdc18fce4cc0df9cd6", null ]
];