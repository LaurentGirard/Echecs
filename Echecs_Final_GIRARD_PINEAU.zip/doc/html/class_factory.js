var class_factory =
[
    [ "Factory", "class_factory.html#ac792bf88cfb7b6804b479529da5308cc", null ],
    [ "~Factory", "class_factory.html#a8f71456f48e4df402c778a44191ff40e", null ],
    [ "buildPieces", "class_factory.html#a90f20f663caa6e5a5370465d3014630f", null ]
];