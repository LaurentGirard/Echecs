var class_factory_bishop =
[
    [ "FactoryBishop", "class_factory_bishop.html#a6452991e628ec8262c57318da26171f1", null ],
    [ "~FactoryBishop", "class_factory_bishop.html#aacec6859e5c70571357c5d172a62a38e", null ],
    [ "buildPieces", "class_factory_bishop.html#a501a01fc371b26931d528ea0aa8b5c14", null ]
];