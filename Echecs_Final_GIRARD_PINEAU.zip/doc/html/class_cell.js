var class_cell =
[
    [ "Cell", "class_cell.html#a4ccfb0a9923271daba6000afa1a33ee9", null ],
    [ "~Cell", "class_cell.html#a9fa559f7a28e2b4336c6879ca09304d8", null ],
    [ "getX", "class_cell.html#a09a86af000a7b6b00be01c0ea71e5319", null ],
    [ "getY", "class_cell.html#a54bd0f63ff375abde26902cc2ca7ea78", null ],
    [ "operator==", "class_cell.html#ae889f79cafc3dda80d430980e4418333", null ],
    [ "setX", "class_cell.html#a5db21f79684f86d4dad8e17a40bbb797", null ],
    [ "setY", "class_cell.html#ad797a4c776783b15f4637b1f667f56a5", null ]
];