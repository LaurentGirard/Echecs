var class_null_state =
[
    [ "NullState", "class_null_state.html#a16b8bc7f006616e9c057ddf2b1ec811d", null ],
    [ "~NullState", "class_null_state.html#a3d286ab0ced8da71c8729871d1bd3aae", null ],
    [ "check", "class_null_state.html#a04825452cd1018dec2525609a3079aff", null ],
    [ "checkMate", "class_null_state.html#a2bc6da41f64658fb9f733f6b23f0e499", null ],
    [ "gameEnd", "class_null_state.html#a73b1449815c3770ac24e56fa885a7961", null ],
    [ "gameNull", "class_null_state.html#a9a735f7e4cbf7c3439208f9bb90b649d", null ],
    [ "inGame", "class_null_state.html#a3c51a85d1d0273b7f7db4ed20672c68c", null ],
    [ "ischeck", "class_null_state.html#a8da9c3d889ff161f893d5522a89567a5", null ],
    [ "isCheckMate", "class_null_state.html#a0b43994870d835258a68300d710992ac", null ],
    [ "isnulle", "class_null_state.html#a0aa0845d4f2ce4f86749bd73edb8c8da", null ],
    [ "print", "class_null_state.html#a5a2b2f419bba204759bf344c8b7710d0", null ]
];