var class_bishop =
[
    [ "Bishop", "class_bishop.html#a7e73da51fcaac88ce0d16e78221142ee", null ],
    [ "~Bishop", "class_bishop.html#a3705b4537a39d09a59143fe01a62442f", null ],
    [ "movement", "class_bishop.html#abd25da5816a737ab64880cbaa7bd7582", null ]
];