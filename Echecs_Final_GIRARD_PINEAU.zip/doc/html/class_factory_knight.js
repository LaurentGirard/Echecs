var class_factory_knight =
[
    [ "FactoryKnight", "class_factory_knight.html#a4c3de6c385f4b3d02286e39cdbf99136", null ],
    [ "~FactoryKnight", "class_factory_knight.html#a40846bdf0be3fb8ecbcb50df3c4a7f61", null ],
    [ "buildPieces", "class_factory_knight.html#a25af606063189d96698aae45b1bfc1b9", null ]
];