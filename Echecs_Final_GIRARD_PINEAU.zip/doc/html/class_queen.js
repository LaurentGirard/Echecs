var class_queen =
[
    [ "Queen", "class_queen.html#a90ebaca4522d07b5a662b20c09a968aa", null ],
    [ "~Queen", "class_queen.html#aa22f6c1a49a583b549bd1f940e50721d", null ],
    [ "movement", "class_queen.html#a6cf9ea1320f2ebe6fa9bb35430e63603", null ]
];