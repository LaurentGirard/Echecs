var class_factory_queen =
[
    [ "FactoryQueen", "class_factory_queen.html#ab6cc7393c4cb1670ba041a44276a58cd", null ],
    [ "~FactoryQueen", "class_factory_queen.html#ab1e9dfe91a868c88b775d3220b8f9bc0", null ],
    [ "buildPieces", "class_factory_queen.html#ac256e556b525b35d39f58af62fd1f962", null ]
];