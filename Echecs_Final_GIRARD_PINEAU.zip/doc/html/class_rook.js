var class_rook =
[
    [ "Rook", "class_rook.html#ab9613a93abc8a73bda94c596868ec1b1", null ],
    [ "~Rook", "class_rook.html#a70d445b94848b22ded850b6f58bc2972", null ],
    [ "asMoved", "class_rook.html#afb50e8a85759ba7518b55dace6b6e406", null ],
    [ "movement", "class_rook.html#acc6139577c8ca679a93dcfbe42b71cb3", null ],
    [ "setMoved", "class_rook.html#a7ee5b6169a3fff6d5536ba0c02607950", null ]
];