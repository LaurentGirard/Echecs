var class_team =
[
    [ "Team", "class_team.html#aada295895b747960576b69d8c87a54ba", null ],
    [ "~Team", "class_team.html#ab4218fddd612d52bab47bec4feeb49de", null ],
    [ "buildTeamNormal", "class_team.html#a775920b00268678f778e08c0bf3ef514", null ]
];