var searchData=
[
  ['square',['square',['../class_piece.html#a1e38a3d73f5f7171eca664a77c7aaeff',1,'Piece']]]
];
