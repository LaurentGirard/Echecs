var searchData=
[
  ['alive',['alive',['../class_piece.html#a8b3c2f812ead74ba513f521e63f767f9',1,'Piece']]]
];
