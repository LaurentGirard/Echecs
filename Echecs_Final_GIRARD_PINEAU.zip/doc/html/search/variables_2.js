var searchData=
[
  ['movements',['movements',['../class_piece.html#a022b28159d944243023804a678d7024f',1,'Piece']]]
];
