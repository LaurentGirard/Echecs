var searchData=
[
  ['king',['King',['../class_king.html#af934f2cda4bb5baca66c2ae114997b6e',1,'King']]],
  ['knight',['Knight',['../class_knight.html#ae39d8e49ade7c0b66cf35dad69f2d2db',1,'Knight']]]
];
