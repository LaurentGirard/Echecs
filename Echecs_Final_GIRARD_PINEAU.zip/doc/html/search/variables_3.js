var searchData=
[
  ['player',['player',['../class_state.html#a9a024fd38161f32fc10b68b4ccb13226',1,'State']]]
];
