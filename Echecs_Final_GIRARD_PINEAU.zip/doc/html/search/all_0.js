var searchData=
[
  ['alive',['alive',['../class_piece.html#a8b3c2f812ead74ba513f521e63f767f9',1,'Piece']]],
  ['asmoved',['asMoved',['../class_rook.html#afb50e8a85759ba7518b55dace6b6e406',1,'Rook::asMoved()'],['../class_king.html#a1e7d9da6599c3e3ab9cbc4d5026f0dcf',1,'King::asMoved()']]]
];
