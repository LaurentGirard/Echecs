var searchData=
[
  ['asmoved',['asMoved',['../class_rook.html#afb50e8a85759ba7518b55dace6b6e406',1,'Rook::asMoved()'],['../class_king.html#a1e7d9da6599c3e3ab9cbc4d5026f0dcf',1,'King::asMoved()']]]
];
