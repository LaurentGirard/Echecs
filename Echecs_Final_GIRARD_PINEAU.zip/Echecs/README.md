# Echecs

Compiler avec make à la racine du projet

Lancer en exécutant la ligne de commande : ./bin/Echecs

Générer la documentation en tapant : doxygen Doxycfg 