var class_state =
[
    [ "State", "class_state.html#a7a0a6af0cd97aa575a097eca87e090ba", null ],
    [ "~State", "class_state.html#afab438d92b90dc18d194dbd9c9c8bab3", null ],
    [ "check", "class_state.html#a321fd726bbefc35fedbbf001d2a37021", null ],
    [ "checkMate", "class_state.html#aa2b89ec92ecd4f6271269fe4b8ccc790", null ],
    [ "gameEnd", "class_state.html#a5117e1f9bf06e17b4b0277838fe39bd8", null ],
    [ "gameNull", "class_state.html#ad5b7fe10b2c30243f36d7d0950c50d43", null ],
    [ "inGame", "class_state.html#a738b04d6e0c12a39bf96a2a7159202d8", null ],
    [ "ischeck", "class_state.html#ad2d7084c507d8d20be2e772d953129fb", null ],
    [ "isCheckMate", "class_state.html#ac67ccfcdc2d3e9fbe6d05961416ffeda", null ],
    [ "isnulle", "class_state.html#a869f2ebfad7e60719df5f89a613adee1", null ],
    [ "print", "class_state.html#a95a537bb55b9118b23d5bed88ba3b335", null ],
    [ "player", "class_state.html#a9a024fd38161f32fc10b68b4ccb13226", null ]
];