var searchData=
[
  ['queen',['Queen',['../class_queen.html',1,'Queen'],['../class_queen.html#a90ebaca4522d07b5a662b20c09a968aa',1,'Queen::Queen()']]]
];
