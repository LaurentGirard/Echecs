var searchData=
[
  ['bishop',['Bishop',['../class_bishop.html',1,'']]]
];
