var class_king =
[
    [ "King", "class_king.html#af934f2cda4bb5baca66c2ae114997b6e", null ],
    [ "~King", "class_king.html#aac368ce96e2b12f62e3608d27262e941", null ],
    [ "asMoved", "class_king.html#a1e7d9da6599c3e3ab9cbc4d5026f0dcf", null ],
    [ "movement", "class_king.html#aabc0b7a9a553383e7aba11daecbbc61c", null ],
    [ "setMoved", "class_king.html#a29a4ff10443abb0b0ecd088c88861d18", null ]
];