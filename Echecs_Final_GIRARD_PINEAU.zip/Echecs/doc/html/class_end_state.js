var class_end_state =
[
    [ "EndState", "class_end_state.html#a0c74d371934fe30dd66ad3275b0ca98e", null ],
    [ "~EndState", "class_end_state.html#a201636e52f201f6f34318c152139e2e1", null ],
    [ "check", "class_end_state.html#a80e538c38c1293803200e5d3b513ba77", null ],
    [ "checkMate", "class_end_state.html#a48a2531ee4bd2144b44823a5527488f3", null ],
    [ "gameEnd", "class_end_state.html#a6fc13eb28853a79e1b5396dd2f377a51", null ],
    [ "gameNull", "class_end_state.html#ad50c108e27c7b0497c3f2f2e76b904a5", null ],
    [ "inGame", "class_end_state.html#a6ba5aa5cfd2d0ac4aa1609e336d5669f", null ],
    [ "ischeck", "class_end_state.html#ae4ea53e0246be8cf37ccd8cf7b442523", null ],
    [ "isCheckMate", "class_end_state.html#a78472ec2e6794153781eee37f6522fc1", null ],
    [ "isnulle", "class_end_state.html#aa9ccf089beda25f9d258e6a68e2a7309", null ],
    [ "print", "class_end_state.html#a1983377ed8a1e391871fb40db39f13e3", null ]
];