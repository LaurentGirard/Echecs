var class_piece =
[
    [ "Piece", "class_piece.html#ac57de5803bbad829b143bc7268267dc1", null ],
    [ "Piece", "class_piece.html#a26c8c5a537f1733833787820d3f1ff01", null ],
    [ "~Piece", "class_piece.html#a5d7a4f6bade94cb33b6f634de8aa7918", null ],
    [ "getLabel", "class_piece.html#ab0b61a2a0f2f3d977b4b1946ab328f2b", null ],
    [ "getMovements", "class_piece.html#af2a3be14e4732ac3f09a84a9cbefbf5b", null ],
    [ "getSquare", "class_piece.html#a91fddbcc85fe9fbbca1897079ce9b9e5", null ],
    [ "isAlive", "class_piece.html#a9f6a89d6fd5ae865af73c2220d1a5839", null ],
    [ "movement", "class_piece.html#ae721b5ed94376fd4e7d348d36739ed4d", null ],
    [ "printPiece", "class_piece.html#ae9c47c1e15caf3ecf060c274aec62820", null ],
    [ "setAlive", "class_piece.html#ad4161cd37efb373e08b50cdf43b07b5f", null ],
    [ "setSquare", "class_piece.html#af405feca349d71dfacb20b128c3cc686", null ],
    [ "alive", "class_piece.html#a8b3c2f812ead74ba513f521e63f767f9", null ],
    [ "label", "class_piece.html#aec026f7ca20120f0b635591de2f86662", null ],
    [ "movements", "class_piece.html#a022b28159d944243023804a678d7024f", null ],
    [ "square", "class_piece.html#a1e38a3d73f5f7171eca664a77c7aaeff", null ]
];